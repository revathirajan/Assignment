package com.example.assignment.VO;

public class TreatmentVo {
	
	String claimId;
    String date;
    String nameofthedisease;
    int billamt;
    String patientId;
    String dateofAppointment;
    String status;
	public String getClaimId() {
		return claimId;
	}
	public void setClaimId(String claimId) {
		this.claimId = claimId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getNameofthedisease() {
		return nameofthedisease;
	}
	public void setNameofthedisease(String nameofthedisease) {
		this.nameofthedisease = nameofthedisease;
	}
	public int getBillamt() {
		return billamt;
	}
	public void setBillamt(int billamt) {
		this.billamt = billamt;
	}
	public String getPatientId() {
		return patientId;
	}
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}
	public String getDateofAppointment() {
		return dateofAppointment;
	}
	public void setDateofAppointment(String dateofAppointment) {
		this.dateofAppointment = dateofAppointment;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
    
    

}

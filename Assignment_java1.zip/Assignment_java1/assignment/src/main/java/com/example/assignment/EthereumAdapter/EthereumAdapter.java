package com.example.assignment.EthereumAdapter;



import java.io.IOException;
import java.math.BigInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.web3j.crypto.CipherException;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.WalletUtils;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.http.HttpService;

@Configuration
public class EthereumAdapter {

	private static final Logger log = LoggerFactory.getLogger(EthereumAdapter.class);

	@Bean
	public Web3j startEthereum() throws Exception {
		Web3j web3j = Web3j.build(new HttpService("http://localhost:9095"));
		log.info("Connected to Ethereum client version: " + web3j.web3ClientVersion().send().getWeb3ClientVersion());
		return web3j;
	}
	

	
	public Credentials getCredentials() throws IOException, CipherException {
		Credentials credentials = null;
		try {
			credentials = WalletUtils.loadCredentials("",
					"C:\\Users\\Premkumar\\Downloads\\assignment (1)\\assignment\\UTC--2019-01-08T13-41-12.863521767Z--a5e65a1d64f4718aa2497399fdd3a01d2ef3f21a");
		}catch(Exception e) {
			log.error("failure",e);
		}
		return credentials;
	}
	
	public Credentials getAdminCredentials() throws IOException, CipherException {
		Credentials credentials = null;
		try {
			credentials = WalletUtils.loadCredentials("",
					"C:\\Users\\Premkumar\\Downloads\\assignment (1)\\assignment\\UTC--2019-01-08T13-41-12.863521767Z--a5e65a1d64f4718aa2497399fdd3a01d2ef3f21a");
		}catch(Exception e) {
			log.error("failure",e);
		}
		return credentials;
	}


	public BigInteger getGasPrice() {
		BigInteger gasprice= BigInteger.valueOf(4700000);
		return gasprice;
	}
	public BigInteger getGasLimit() {
		BigInteger gaslimit= BigInteger.valueOf(4700000);
		return gaslimit;
	}
}


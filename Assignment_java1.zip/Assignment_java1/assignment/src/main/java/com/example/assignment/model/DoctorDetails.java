package com.example.assignment.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document("DoctorDetails")
public class DoctorDetails {
	String NPINumber;
	String name;
	String address;
	String city;
	long mobile;
	String certificate;
	String areaSpecialist;
	String password;
	String status;
	public String getNPINumber() {
		return NPINumber;
	}
	public void setNPINumber(String nPINumber) {
		NPINumber = nPINumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public String getAreaSpecialist() {
		return areaSpecialist;
	}
	public void setAreaSpecialist(String areaSpecialist) {
		this.areaSpecialist = areaSpecialist;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}

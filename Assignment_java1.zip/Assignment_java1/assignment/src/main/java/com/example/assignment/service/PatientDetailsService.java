package com.example.assignment.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import com.example.assignment.contractwrapper.Adapter;
import com.example.assignment.contractwrapper.TreatmentAdapter;

import org.springframework.stereotype.Service;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.methods.response.TransactionReceipt;

import com.example.assignment.repository.DoctorDetailsRepo;
import com.example.assignment.repository.PatientDetailsRepo;
import com.example.assignment.EthereumAdapter.EthereumAdapter;
import com.example.assignment.VO.AppointmentVo;
import com.example.assignment.VO.DoctorRegistration;
import com.example.assignment.util.*;
import com.example.assignment.VO.PatientDetailsVo;
import com.example.assignment.VO.TreatmentVo;
import com.example.assignment.model.AppointmentDetails;
import com.example.assignment.model.DoctorDetails;
import com.example.assignment.model.PatientDetails;

@Service
public class PatientDetailsService {

@Autowired
PatientDetailsRepo patientrepo;
DoctorDetailsRepo doctorRepo;

@Autowired
private EthereumAdapter ethereumAdapter;

@Autowired
private Web3j web3j;



public String addPatientDetails(PatientDetailsVo patientDetail)

{
	PatientDetails patient = new PatientDetails();
	
	patient.setPatientId(patientDetail.getPatientId());
	patient.setPatientName(patientDetail.getPatientName());
	patient.setUserName(patientDetail.getUserName());
	patient.setPassword(patientDetail.getPassword());
	
	patientrepo.save(patient);
	
	return "Details Added Successfully";
	
	

}


public String addDoctorDetails(DoctorRegistration doctorDetail) {
	
	DoctorDetails doctor = new DoctorDetails();
	
	doctor.setNPINumber(doctorDetail.getNPINumber());
	doctor.setName(doctorDetail.getName());
	doctor.setCity(doctorDetail.getCity());
	doctor.setMobile(doctorDetail.getMobile());
	doctor.setAddress(doctorDetail.getAddress());
	doctor.setPassword(doctorDetail.getPassword());
	doctor.setCertificate(doctorDetail.getCertificate());
	doctor.setAreaSpecialist(doctorDetail.getAreaSpecialist());
	doctor.setStatus(doctorDetail.getStatus());
	doctorRepo.save(doctor);
	
	return "Details Added Sucessfully";
	
}


public boolean  addAppointment(AppointmentVo appointmentDetail,String contractAddress) throws Exception
{
	Adapter wpobj = Adapter.load(contractAddress, web3j, ethereumAdapter.getCredentials(),
			ethereumAdapter.getGasPrice(), ethereumAdapter.getGasLimit());
	TransactionReceipt r = wpobj.addAppointment(DataTypeConverter.stringTo32Byte(appointmentDetail.getPatientId()),appointmentDetail).send();

	if (r != null) {
		System.out.println("contract data- adduser " + r.getTransactionHash());
		return true;
	} else
		return false;

	
}


public List<AppointmentDetails> getAllAppointment(String contractAddress) throws Exception {
	Adapter wpobj = Adapter.load(contractAddress, web3j, ethereumAdapter.getCredentials(),
			ethereumAdapter.getGasPrice(), ethereumAdapter.getGasLimit());
	List<byte[]> r = (List<byte[]>) wpobj.getAllPatientDetails().send();

	System.out.println("contract data- getallusers: " + r.toString());
	List<AppointmentDetails> ls = new ArrayList<>();
	r.forEach(r1 -> {
		ls.addAll((Collection<? extends AppointmentDetails>) new AppointmentDetails());
	});
	if (r != null)
		return ls;
	else
		return null;
}

public List<AppointmentDetails> getPatientById(String contractAddress,String patientId) throws Exception {
	Adapter wpobj = Adapter.load(contractAddress, web3j, ethereumAdapter.getCredentials(),
			ethereumAdapter.getGasPrice(), ethereumAdapter.getGasLimit());
	List<byte[]> r = wpobj.getPatientById(DataTypeConverter.stringTo32Byte(patientId)).send();

	System.out.println("contract data- getallusers: " + r.toString());
	List<AppointmentDetails> ls = new ArrayList<>();
	r.forEach(r1 -> {
		ls.addAll((Collection<? extends AppointmentDetails>) new AppointmentDetails());
	});
	if (r != null)
		return ls;
	else
		return null;
}


public boolean  addTreatment(TreatmentVo treatmentDetail,String contractAddress) throws Exception
{
	TreatmentAdapter wpobj = TreatmentAdapter.load(contractAddress, web3j, ethereumAdapter.getCredentials(),
			ethereumAdapter.getGasPrice(), ethereumAdapter.getGasLimit());
	TransactionReceipt r = wpobj.addTreatmentDetail(DataTypeConverter.stringTo32Byte(treatmentDetail.getPatientId()),treatmentDetail).send();

	if (r != null) {
		System.out.println("contract data- adduser " + r.getTransactionHash());
		return true;
	} else
		return false;

	
}


public List<TreatmentVo> getAllTreatment(String contractAddress) throws Exception {
	TreatmentAdapter wpobj = TreatmentAdapter.load(contractAddress, web3j, ethereumAdapter.getCredentials(),
			ethereumAdapter.getGasPrice(), ethereumAdapter.getGasLimit());
	List<byte[]> r = (List<byte[]>) wpobj.getAllTreatmentDetails().send();

	System.out.println("contract data- getallusers: " + r.toString());
	List<TreatmentVo> ls = new ArrayList<>();
	r.forEach(r1 -> {
		ls.addAll((Collection<? extends TreatmentVo>) new TreatmentVo());
	});
	if (r != null)
		return ls;
	else
		return null;
}

public List<TreatmentVo> getTreamentById(String contractAddress,String patientId) throws Exception {
	TreatmentAdapter wpobj = TreatmentAdapter.load(contractAddress, web3j, ethereumAdapter.getCredentials(),
			ethereumAdapter.getGasPrice(), ethereumAdapter.getGasLimit());
	List<byte[]> r = wpobj.getTreatmentById(DataTypeConverter.stringTo32Byte(patientId)).send();

	System.out.println("contract data- getallusers: " + r.toString());
	List<TreatmentVo> ls = new ArrayList<>();
	r.forEach(r1 -> {
		ls.addAll((Collection<? extends TreatmentVo>) new TreatmentVo());
	});
	if (r != null)
		return ls;
	else
		return null;
}




}

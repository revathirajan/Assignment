package com.example.assignment.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.assignment.model.PatientDetails;

public interface PatientDetailsRepo extends MongoRepository<PatientDetails,String> {
	
	
	

}

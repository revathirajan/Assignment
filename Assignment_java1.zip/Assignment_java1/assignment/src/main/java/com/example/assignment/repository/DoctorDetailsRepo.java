package com.example.assignment.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.assignment.model.DoctorDetails;

public interface  DoctorDetailsRepo extends MongoRepository<DoctorDetails,String> {

}

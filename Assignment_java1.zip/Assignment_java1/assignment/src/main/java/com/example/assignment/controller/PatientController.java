package com.example.assignment.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.assignment.VO.AppointmentVo;
import com.example.assignment.VO.DoctorRegistration;
import com.example.assignment.VO.PatientDetailsVo;
import com.example.assignment.VO.TreatmentVo;
import com.example.assignment.service.PatientDetailsService;
import com.example.assignment.model.PatientDetails;
import com.example.assignment.repository.DoctorDetailsRepo;
import com.example.assignment.repository.PatientDetailsRepo;
import com.example.assignment.model.AppointmentDetails;
import com.example.assignment.model.DoctorDetails;



@RestController
public class PatientController {
	
@Autowired
PatientDetailsService patientService;

@Autowired
PatientDetailsRepo patientrepo;

@Autowired
DoctorDetailsRepo doctorrepo;
	
	
	@PostMapping("/api/addPatientDetails/")
	public String addPatientDetails(@RequestBody  PatientDetailsVo request) {
		
		String response=patientService.addPatientDetails(request);
		return response;
		
		
		
	}
	
	@PostMapping("/api/addDoctorDetails/")
	public String addDoctorDetails(@RequestBody  DoctorRegistration request) {
		
		String response=patientService.addDoctorDetails(request);
		return response;
		
		
		
	}
	
	@PostMapping("/api/addAppointment/")
	public boolean addAppointment(@RequestBody  AppointmentVo request,String contractAddress) throws Exception {
		
		boolean response=patientService.addAppointment(request,contractAddress);
		return response;
		
		
		
	}
	
	@PostMapping("/api/addTreamentDetails/")
	public boolean addTreamentDetails(@RequestBody  TreatmentVo request,String contractAddress) throws Exception {
		
		boolean response=patientService.addTreatment(request,contractAddress);
		return response;
		
		
		
	}
	
	@GetMapping("/api/getAllPatients/")
	public List<PatientDetails> getAllPatients() {
		

		List<PatientDetails> Patientlist = patientrepo.findAll();
		
		return Patientlist;
		
		
		
	}
	
	
	@GetMapping("/api/getAllAppointments/")
	public List<AppointmentDetails> getAllAppointments(String contractAddress) throws Exception {

		
		 List<AppointmentDetails> details=patientService.getAllAppointment(contractAddress);
		 
		 return details;
		
	}
	
	
	@GetMapping("/api/getAllTreatmentDetails/")
	public List<TreatmentVo> getAllTreatmentDetails(String contractAddress) throws Exception {

		
		 List<TreatmentVo> details=patientService.getAllTreatment(contractAddress);
		 
		 return details;
		
	}
	
	
	@GetMapping("/api/getAppointmentByPatientId/")
	public List<AppointmentDetails> getAppointmentByPatientId(String contractAddress,String patientId) throws Exception {

		
		 List<AppointmentDetails> details=patientService.getPatientById(contractAddress,patientId);
		 
		 return details;
		
	}
	
	@GetMapping("/api/getTreatemtById/")
	public List<TreatmentVo> getTreatemtById(String contractAddress,String patientId) throws Exception {

		
		 List<TreatmentVo> details=patientService.getTreamentById(contractAddress,patientId);
		 
		 return details;
		
	}
	@GetMapping("/api/getAllDoctorDetails/")
	public List<DoctorDetails> getAllDoctors() {
		

		List<DoctorDetails> Doctorlist = doctorrepo.findAll();
		
		return Doctorlist;
		
		
		
	}


}

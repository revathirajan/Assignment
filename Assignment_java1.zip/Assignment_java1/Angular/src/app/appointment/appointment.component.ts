import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }
  getAllAppointments()
  {
   this.data.getAllAppointments().subscribe(item => {


     this.entity=item;
     for(let list of this.entity)
     {
    this.docs.push(list._source);
     }
 ELEMENT_DATA = this.docs
 this.dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
 this.dataSource.paginator = this.paginator;
 this.show=true;
 this._router.navigate([''])
 },error => {
 console.log("error");
 });
 }


  addAppointmentDetails()
  {
   this.data.addAppointment(this.request).subscribe(item => {
     // console.log(item.hits.hits);
     // this.entity=item.hits.hits;
    console.log(item);
 },error => {
 console.log("error");
 });
 }

}


var ELEMENT_DATA: PeriodicElement[] = [];

export interface PeriodicElement {
  PatientName: string;
  PatientId: string;
  Age: string;
  Mobile: string;
  Address: string;
  Reason:String;

}

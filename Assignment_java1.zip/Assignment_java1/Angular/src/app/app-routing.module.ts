import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DownloadComponent } from './download/download.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { NavComponent } from './nav/nav.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [
  { path: 'home', component : HomeComponent },
  { path: 'about', component: AboutComponent }, 
  { path: 'login', component: LoginComponent} ,
  { path: 'download', component: DownloadComponent} ,
  { path: '', component: NavComponent} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { BrowserModule } from '@angular/platform-browser';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { NgModule,Injector} from '@angular/core';
import {MatTableModule} from '@angular/material/table';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { DialogOverviewExampleDialog } from './nav/nav.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import {MatCardModule} from '@angular/material/card';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatDividerModule} from '@angular/material/divider'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule} from '@angular/material/dialog';
import { MatPaginatorModule } from '@angular/material';
import {MatTooltipModule} from '@angular/material/tooltip';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { createCustomElement } from '@angular/elements';
import { SlickModule } from 'ngx-slick';
import {ScrollDispatchModule} from '@angular/cdk/scrolling';
import { AppointmentComponent } from './appointment/appointment.component';
import { TreatmentComponent } from './treatment/treatment.component';

@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    HomeComponent,
    LoginComponent,
    DialogOverviewExampleDialog,
    AppointmentComponent,
    TreatmentComponent
  ],
  imports: [
    BrowserModule,SlickModule,
    AppRoutingModule,
    HttpClientModule,MatPaginatorModule,
    ReactiveFormsModule,MatDialogModule,
    MatInputModule, MatSelectModule,
    BrowserAnimationsModule,FormsModule,MatTableModule,MatDividerModule,MatGridListModule
    ,MatSidenavModule,MatCardModule,MatProgressSpinnerModule,MatButtonModule,MatTooltipModule,
    DragDropModule,ScrollDispatchModule

  ],
  providers: [],
  bootstrap: [AppComponent],
  entryComponents: [DialogOverviewExampleDialog]
})
export class AppModule {
  constructor(private injector: Injector) {
    const slider = createCustomElement(NavComponent, { injector });
    customElements.define('motley-slider', slider);
  }
  ngDoBootstrap(){}
 }

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MatInputModule } from '@angular/material/input';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  submitted = false;
  success = false;

   userTypes = ['Cateloger','Reviewer','Publisher'];

  constructor(private formBuilder: FormBuilder, private _router: Router) { }
  loggedInUser: Object;
  userType: String;
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      name: ['', Validators.required],
      pass: ['', Validators.required],
      type: ['',Validators.required]
    });


  }

  onSubmit() {
    this.submitted = true;

    if (this.loginForm.invalid) {
        return;
    }
    sessionStorage.setItem("loggedInUser", this.loginForm.controls.name.value);
    this.userType = this.loginForm.controls.type.value;
  }

  onReset() {
    this.submitted = false;
  }

}

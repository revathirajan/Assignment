import { Component, OnInit,ViewChild  } from '@angular/core';
import {MatPaginator, MatTableDataSource} from '@angular/material';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { DataService } from '../data.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  displayedColumns: string[] = ["PatientId","PatientName","UserName","Password"];
  show=false;
  filtersearch=false;
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  category:string;
  keyword:string;
  users: Object;
  abstract:string;
  request={ "query": { "match": { } } };
  request1={"query": {"wildcard" : { }}};
  request3={"query": {"match_all": {}}};
  docs=[];
  entity=[];
  events=[];

  constructor(private data: DataService,private _router: Router) { }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngOnInit() {

    this.getPatientDetails();

    // this.data.getUsers().subscribe(data => {
    //     this.users = data
    //     console.log(this.users);
    //   });

  }
     getPatientDetails()
     {
      this.data.getPatientDetails(this.request).subscribe(item => {
        // console.log(item.hits.hits);
         this.entity=item;
        for(let list of this.entity)
        {
       this.docs.push(list._source);
        }
    ELEMENT_DATA = this.docs
    this.dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
    this.dataSource.paginator = this.paginator;
    this.show=true;
    this._router.navigate([''])
  },error => {
    console.log("error");
  });
  }



}

var ELEMENT_DATA: PeriodicElement[] = [];

export interface PeriodicElement {
  PatientName: string;
  PatientId: string;
  UserName: string;
  Password: string;

}

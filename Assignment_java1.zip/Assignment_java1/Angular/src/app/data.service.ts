import { Injectable } from '@angular/core';
import { HttpClient ,} from '@angular/common/http';
import { Headers } from '@angular/http';
const URL = '../assets/data.json';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  getAllPatients() {
    return this.http.get('https://localhost:8095/api/getAllPatients/')
  }
   addPatientDetails(request,address){
    console.log(request);
    const headers = new Headers();
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'GET');
    headers.append('Access-Control-Allow-Origin', '*');

  return this.http.post("http://localhost/api/addPatientDetails",request,address,{});
}

addDoctorDetails(request,address){
 console.log(request);
 const headers = new Headers();
 headers.append('Access-Control-Allow-Headers', 'Content-Type');
 headers.append('Access-Control-Allow-Methods', 'GET');
 headers.append('Access-Control-Allow-Origin', '*');

return this.http.post("http://localhost/api/addDoctorDetails",request,address,{});
}

addAppointment(request,address){
 console.log(request);
 const headers = new Headers();
 headers.append('Access-Control-Allow-Headers', 'Content-Type');
 headers.append('Access-Control-Allow-Methods', 'GET');
 headers.append('Access-Control-Allow-Origin', '*');
 console.log("http://52.40.149.92/elasticsearch/_search");
return this.http.post("http://localhost/api/addAppointment",request,address,{});
}

getAllAppointments() {
  return this.http.get('https://localhost:8095/api/getAllAppointments/')
}


getAllTreatmentDetails(contractaddress)
{
  return this.http.get("https://localhost:8095/api/getAllAppointments/",contractaddress);
}


getAppointmentByPatientId(PatientID,contractaddress)
{
  return this.http.get("https://localhost:8095/api/getAppointmentByPatientId/",PatientID,contractaddress);
}

getTreatemtById(PatientID,contractaddress)
{
  return this.http.get("https://localhost:8095/api/getTreatemtById/",PatientID,contractaddress);
}

}
